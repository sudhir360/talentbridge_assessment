export custoner={
    name:string
}